package com.example.testeothreads

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    val frasesH = arrayOf("Inserto frase 1", "Inserto frase 2", "Inserto frase 3")

    var b = true

    var buttoniniciar : Button? = null
    var button2pausar : Button? = null
    var button3reanudar : Button? = null
    var frases : TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        buttoniniciar = findViewById(R.id.buttoniniciar)
        button2pausar = findViewById(R.id.button2pausar)
        button3reanudar = findViewById(R.id.button3reanudar)
        frases = findViewById(R.id.frases)

        buttoniniciar!!.setOnClickListener {
            var hilo = HiloUno(this)
            hilo.start()
            b =true
        }
        button2pausar!!.setOnClickListener {
            b= false
        }
        button3reanudar!!.setOnClickListener {
            b= true
        }


    }
}

class HiloUno(activity: MainActivity) :Thread(){
    var i = 0
    var act = activity
    var tamaño = act.frasesH.size
    override fun run() {
        super.run()
        while (true){
            act.runOnUiThread {
                if (act.b==false){ //revisar el frases de abajo, puede ser el id del text view
                    act.frases!!.setText(act.frasesH.get(i))
                }
                else{
                    act.frases!!.setText(act.frasesH.get(i))
                    i++
                    if (i==tamaño)
                        i=0
                }
            }
            Thread.sleep(8000)
        }
    }
}