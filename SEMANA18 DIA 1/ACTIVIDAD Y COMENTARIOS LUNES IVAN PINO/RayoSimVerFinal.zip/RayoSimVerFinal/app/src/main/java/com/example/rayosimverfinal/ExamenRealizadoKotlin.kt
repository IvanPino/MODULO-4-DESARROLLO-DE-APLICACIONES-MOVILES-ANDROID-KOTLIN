package com.example.rayosimverfinal

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ExamenRealizadoKotlin : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_examen_realizado_kotlin)
    }
}

//HACER BOTON QUE MANDE A PANTALLA DE INICIO